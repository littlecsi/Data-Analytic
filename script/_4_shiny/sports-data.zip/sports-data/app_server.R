library("shiny")
library("ggplot2")
library("dplyr")
library("plotly")
library("tidyr")
library("rlang")
library("lintr")
library("stringr")

dataframe <- read.csv("data/injuries.csv", stringsAsFactors = FALSE)

# Creates a dataframe with a column only containing the year
dataframe_with_year <- dataframe %>%
  mutate(year = as.numeric(substr(Date, 1, 4)))

# Creates a dataframe without blank rows
dataframe_no_blanks <- dataframe %>%
  mutate(player = ifelse(Relinquised == "", Acquired, Relinquised))

# Dataframe with the most injuries
most_injured <- dataframe_no_blanks %>%
  select(player) %>%
  group_by(player) %>%
  summarise(injuries = n()) %>%
  arrange(-injuries)

# Top ten most injuries
the_top_ten <- most_injured[1:10, ]

# Adds a column for only the description of the injury.
dataframe_no_blanks$injury <- gsub("\\s*\\([^\\)]+\\)", "",
                                   as.character(dataframe_no_blanks$Notes))

# Removed columns not needed for calculation
overall_df <- dataframe_no_blanks %>%
  select(-Acquired, -Relinquised)

my_server <- function(input, output) {

  # Creates horizontal bar graph for the fourth page.
  output$hbar <- renderPlotly({
    top_injuries <- overall_df %>%
      mutate(year = as.numeric(substr(Date, 1, 4))) %>%
      select(year, injury) %>%
      filter(year == input$slider2,
             injury != "returned to lineup",
             injury != "rest",
             injury != "DNP") %>%
      group_by(injury) %>%
      summarise(total = n()) %>%
      arrange(-total)

    top_15_injuries <- top_injuries[1:15, ]
    top_15_injuries <- top_15_injuries[order(top_15_injuries$total), ]

    # Allows to sort bars from largest to smallest
    yform <- list(categoryorder = "array",
                  categoryarray = top_15_injuries$injury)

    horizontal <- plot_ly(top_15_injuries,
                          x = ~total,
                          y = ~injury,
                          type = "bar",
                          orientation = "h") %>%
      layout(yaxis = yform,
             title = paste("Top 15 Injuries for the Year", input$slider2),
             xaxis = list(title = "Number of Occurances"))
    return(horizontal)
  })


  # Creates animated line graph for third page
  output$line <- renderPlotly({
    single_team <- dataframe_no_blanks %>%
      select(-Acquired, -Relinquised) %>%
      filter(Team == input$text) %>%
      mutate(year = as.numeric(substr(Date, 1, 4)))

    single_team_injuries <- single_team %>%
      select(year) %>%
      group_by(year) %>%
      summarise(injuries = n())

    # Allows for cumulative line animation
    accumulate_by <- function(dat, var) {
      var <- lazyeval::f_eval(var, dat)
      lvls <- plotly:::getLevels(var)
      dats <- lapply(seq_along(lvls), function(x) {
        cbind(dat[var %in% lvls[seq(1, x)], ], frame = lvls[[x]])
      })
      dplyr::bind_rows(dats)
    }

    d <- single_team_injuries %>%
      accumulate_by(~year)

    line_graph <- plot_ly(d,
                          x = ~year,
                          y = ~injuries,
                          frame = ~frame,
                          text = ~paste(d$injuries, "injuries in", d$year),
                          type = "scatter",
                          mode = "lines",
                          line = list(simplyfy = F)) %>%
      layout(
        title = paste("Injury Trend from 2010 to 2018 for the", input$text),
        xaxis = list(
          title = "Year",
          zeroline = F
        ),
        yaxis = list(
          title = "Injuries",
          zeroline = F
        )
      ) %>%
      animation_opts(
        frame = 100,
        transition = 0,
        redraw = FALSE
      ) %>%
      animation_slider(
        hide = T
      ) %>%
      animation_button(
        x = 1, xanchor = "right", y = 0, yanchor = "bottom"
      )
    return(line_graph)
  })


  output$barone <- renderPlotly({
    # Dataframe of top 5 injured players of selected year
    top_5_players <- dataframe_with_year %>%
      select(year, Relinquised) %>%
      group_by(Relinquised) %>%
      filter(year == input$slider1) %>%
      summarise(injuries = n()) %>%
      arrange(-injuries)

    no_blanks <- top_5_players[!(is.na(top_5_players$Relinquised) |
                                   top_5_players$Relinquised == ""), ]

    top_5_players_injured <- no_blanks[1:5, ]

    bar_chart <- plot_ly(top_5_players_injured,
                         x = ~Relinquised,
                         y = ~injuries,
                         type = "bar",
                         textposition = "auto"
    ) %>%
      layout(yaxis = list(title = "Number of Injuries"),
             xaxis = list(title = "Player Names"),
             title = paste("Top 5 Most Injured Players for the Year",
                           input$slider1))
    return(bar_chart)
  })

  output$table <- renderPlotly({
    # Summary statistic table
    plot_table <- plot_ly(
      type = "table",
      columnwidth = c(100, 100),
      columnorder = c(0, 1),
      header = list(
        values = c("Player", "Number of Injuries"),
        align = c("center", "center"),
        line = list(width = 1, color = "black"),
        fill = list(color = c("grey", "grey")),
        font = list(family = "Arial", size = 14, color = "white")
      ),
      cells = list(
        values = rbind(the_top_ten$player, the_top_ten$injuries),
        align = c("center", "center"),
        line = list(color = "black", width = 1),
        font = list(family = "Arial", size = 12, color = c("black"))
      ))
    return(plot_table)

  })
}
