library("dplyr")
library("ggplot2")
library("stringr")
nba_injuries <- read.csv("data/injuries.csv", stringsAsFactors = F)
# This function takes in a dataframe and returns a line graph that shows the
# number of injuries in each year.
get_violin_plot <- function(dataset) {
  grouped_team <- dataset %>%
    filter(Team != "") %>%
    group_by(Team) %>%
    summarise(Number_of_Injuries = n())
  injuries_versus_team <- ggplot(data = grouped_team) +
    geom_violin(mapping = aes(x = "NBA Teams", y = Number_of_Injuries)) +
    labs(
      title = "NBA Team vs amount of injuries",
      y = "Number of Injuries"
    )
  return(injuries_versus_team)
}
