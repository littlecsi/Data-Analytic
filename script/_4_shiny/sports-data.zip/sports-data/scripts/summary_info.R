library(dplyr)
library(knitr)
library(ggplot2)


# injuries data set
injury_data <- read.csv("data/injuries.csv", stringsAsFactors = F)


get_summary_info <- function(dataset) {
  summary_info <- list()

# compute most injuries in a year
most_injury_in_year <- dataset %>%
  filter(Team != "") %>%
  mutate(year = as.integer(substr(Date,1,4))) %>%
  group_by(year) %>%
  summarise(COUNT = n()) %>%
  arrange(-COUNT) %>%
  top_n(1) %>%
  pull(COUNT)

# compute most injured team
most_injured_team <- dataset %>%
  filter(Team != "") %>%
  mutate(year = as.integer(substr(Date,1,4))) %>%
  group_by(Team) %>%
  summarise(COUNT = n()) %>%
  arrange(-COUNT) %>%
  top_n(1) %>%
  pull(Team)


# compute least injuries in a year
least_injury_in_year <- dataset %>%
  filter(Team != "") %>%
  mutate(year = as.integer(substr(Date,1,4))) %>%
  group_by(year) %>%
  summarise(COUNT = n()) %>%
  arrange(COUNT) %>%
  top_n(-1) %>%
  pull(COUNT)

# compute  most injured player
  top_injured_table <- sort(table(dataset[["Relinquised"]]), decreasing = T)
  top_injured_player <- top_injured_table[2]


# compute most common injury
  most_common_injury <- sort(table(dataset[["Notes"]]), decreasing = T)
  top_common_injury <- most_common_injury[2]

  summary_info <- c(most_injury_in_year, most_injured_team, least_injury_in_year,
              top_injured_player, top_common_injury)
  return(summary_info)
}


