library(dplyr)
library(knitr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(stringr)

# This function takes in a dataframe and returns a table that shows the
# number of injuries based on each team.

get_summary_table <- function(dataset) {
  year_injuries_per_team <- nba_injuries %>%
    filter(Team != "") %>%
    mutate(year = as.integer(substr(Date, 1, 4))) %>%
    group_by(Team) %>%
    summarise(COUNT = n())

  summary_table <- kable(year_injuries_per_team,
    col.names = c("Team", "The Number of Injuries")
  )
  return(summary_table)
}
