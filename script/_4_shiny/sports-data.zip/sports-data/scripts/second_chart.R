library(dplyr)
library(knitr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(stringr)

# This function takes in a dataframe and returns a bar graph that shows the
# most common injuries players experience based on the number of injuries

get_bar_graph <- function(df) {
  index <- c("DNP", "DTD", "out indefinitely", "out for season",
             "left game", "CBC")

  base_data <- df %>%
    filter(Team != "") %>%
    mutate(
      year = year(Date),
      month = month(Date),
      day = day(Date)
    ) %>%
    mutate(result = "") %>%
    mutate(result = ifelse(grepl(index[1], Notes) == T,
      paste0(result, ",", index[1]), result
    )) %>%
    mutate(result = ifelse(grepl(index[2], Notes) == T,
      paste0(result, ",", index[2]), result
    )) %>%
    mutate(result = ifelse(grepl(index[3], Notes) == T,
      paste0(result, ",", index[3]), result
    )) %>%
    mutate(result = ifelse(grepl(index[4], Notes) == T,
      paste0(result, ",", index[4]), result
    )) %>%
    mutate(result = ifelse(grepl(index[5], Notes) == T,
      paste0(result, ",", index[5]), result
    )) %>%
    mutate(result = ifelse(grepl(index[6], Notes) == T,
      paste0(result, ",", index[6]), result
    )) %>%
    mutate(result = ifelse(result == "", paste0(result, ",", "others"),
      result
    )) %>%
    separate(result, c("dumi", "a", "b", "c"), sep = ",")

  arragned_data <- base_data %>%
    select(a, b, c)
  data_result <- data.frame()
  for (i in seq(1, length(index), 1)) {
    re_arragned_data <- sum(str_count(arragned_data, pattern = index[i]))
    data_result <- rbind(data_result, re_arragned_data)
  }

  row.names(data_result) <- seq(1, 6, 1)

  colnames(data_result) <- "the_num_injuries"

  final_result <- data_result %>%
    mutate(injury_status = index)

  common_injuries_graph <- ggplot(data = final_result) +
    geom_col(
      mapping = aes(x = c("DNP", "DTD", "Out Indefinitely", "Out for Season",
                          "Left Game", "CBC"), y = the_num_injuries),
      fill = "lightblue", colour = "black", width = 1
    ) +
    labs(
      title = "The Most Common Injuries from 2010 to 2018",
      x = "The Status of Common Injuries", y = "The Number of Injuries"
    )
  return(common_injuries_graph)
}
