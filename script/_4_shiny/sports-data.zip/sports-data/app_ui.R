library("shiny")
library("ggplot2")


page_one <- tabPanel(
  "Introduction to NBA Injuries", # label for the tab in the navbar
  h1("Injuries in the National Basketball Association"),
  tags$br(),
  tags$img(src = "ball.jpg", alt = "Photo by Edgar Chaparro on Unsplash",
           width = "600px",
           height = "auto"),
  tags$br(),=
  p("In many sports, injuries are prone to happen. Even at the professional
    level there can be many injuries. Because so many injuries happen, these
    instances are certain to be tracked and recorded down. Details on injuries
    can be important because it can provide valuable imformation on different
    aspects such as if a sport gear is safe enough, if there should be any rule
    changes that could make the game safer for all players, or to just see
    interesting trends. While injuries can be a common occurrance for all
    sports, this report will be centered around injuries occuring in the NBA.
    The goal of this project is to see the different trends and statistics in
    injuries in the NBA from 2010 to 2018, and to see if there are any
    interesting features we can find about injuries throughout those years. The
    data we are using for this information comes from the Kaggle user Randall
    Hopkins who scrapped the data from the Pro Sports Transactions website."),
  h2("Some questions we hope to answer in this project are:"),
  tags$ul(
    tags$li("What are the most common injuries among NBA players?"),
    tags$li("Which teams have had the most injuries?"),
    tags$li("Which players have had the most injuries?")
  )
)

page_two <- tabPanel(
  "Players With the Most Injuries", # label for the tab in the navbar
  titlePanel("Data on Players with the Most Injuries"), # show with a displayed title

  # This content uses a sidebar layout
  sidebarLayout(
    sidebarPanel(
      sliderInput("slider1",
                  label = h3("Drag to Select Year"),
                  min = 2010,
                  max = 2018,
                  value = 2010,
                  step = 1,
                  round = TRUE,
                  sep = "")
    ),
    mainPanel(
      h2("The Top 5 Most Injured Players in a Year"),
      p("Below you will see a bar chart to show the top 5 players with the most
        injuries within the given year. This chart attempts to understand how
        the players with the most injuries change from year to year as well as
        if the number of injuries of these players change as well."),
      plotlyOutput("barone"),
      h2("Top 5 Most Injured Players 2010 to 2018"),
      p("Below you will see a visual of the top 10 players who have accumulated
        the most injuries from 2010 until 2018."),
      plotlyOutput("table")
    )
  )
)

page_three <- tabPanel(
  "Single Team Injury Statistics", # label for the tab in the navbar
  titlePanel("Interactive Line Graph"), # show with a displayed title

  # This content uses a sidebar layout
  sidebarLayout(
    sidebarPanel(
      textInput("text", label = h3("Enter a Team Name (Use Capitalization)"),
                value = "Warriors")
    ),
    mainPanel(
      h2("The Yearly Injury Trend for a Single Team from 2010 to 2018"),
      p("Below you will see an animated line graph that shows the number of
        injuries for a single NBA team and how these injuries differ from
        year to year. This attempts to answer what the injury trend of each
        team looks like between 2010 to 2018."),
      plotlyOutput("line")
    )
  )
)

page_four <- tabPanel(
  "Top Injuries By Year", # label for the tab in the navbar
  titlePanel("Data on Top 15 Injuries By Selected Year"), # show with a displayed title

  # This content uses a sidebar layout
  sidebarLayout(
    sidebarPanel(
      sliderInput("slider2",
                  label = h3("Drag to Select Year"),
                  min = 2010,
                  max = 2018,
                  value = 2010,
                  step = 1,
                  round = TRUE,
                  sep = "")
    ),
    mainPanel(
      h2("The Top 15 Injuries"),
      p("This horizontal bar chart shows the top 15 most common injuries that
        occured for the chosen year. This helps explain how common injuries
        has changed from year to year, as well as the number of times each
        of these injuries has occured."),
      plotlyOutput("hbar")
    )
  )
)

page_five <- tabPanel(
  "Conclusion", # label for the tab in the navbar
  h1("What We Can Takeaway From This Data...")
)

my_ui <- navbarPage(
  theme = "style.css",
  "Analysis of NBA Injuries", # application title
  page_one,
  page_two,
  page_three,
  page_four,
  page_five

)