# Final Project
Use this `REAMDE.md` file to describe your final project (as detailed on Canvas).

The field we are interested in is sports. We are interested in
this field because most of our group members participate in sports, and sports
can provide us with many different statistics and data given that there are many
different type of sports played around the world. Sports can bring a community
together, and knowing the data on sports can help provide information on many
different categories such as injuries or scoring.

## Some other examples of data driven projects related to sports:

1. https://noahveltman.com/nflplayers/
This dataset portrays the change of the height and weight of NFL players over
its history. This relates to our field of interest because it deals with how
different the sport has become in terms of physicality.

2. http://thesportdigest.com/2018/11/the-impact-of-social-media-in-sports/
This article describes that social media is one of the most important tools for
sports, the fans and the athletes. Also, with the huge growth of social media
users, it portrays how people can engage in the sports, follow their favorite
athletes and teams, and get the most updated sports contents instantaneously.

3. https://www.statlas.co/about.php is a project that gives graphic recaps of
baseball games sorted by date. Each graphic shows the scores for both teams per
inning and the final score below.


## Data driven questions we have about this domain:

1. How often do athletes talk about sports on social media?
2. How do athletes use their platform in sports to influence social media?
3. How is age related to how often a tennis place serves an ace?
4. What is the relation between the height and the number of touchdowns of an
   NFL wide receiver?
5. How is the average age on an NBA team related to success?
6. How does the time elapsed in a game impact how well a player scores?
7. How does the average score a game change throughout history?
8. How does pitch type/velocity affect outcome?
9. How does playing time affect athletes' performances?
10. What is the relation between athletes' ages and grades in matches?
11. Which types of injuries has a specific player sustained?
12. What was the most injuries players suffered from?
13. What is the detrimental injury that can make athletes season out?

## Our sources of data:

1. The data set from
https://www.kaggle.com/speckledpingu/nfl-qb-stats/downloads/nfl-qb-stats.zip/2
was collected by a Kaggle user who used an HTML read function to go through
footballdb.com and collect information on almost every regular season NFL game.
This dataset is focused mainly on quarterback statistics from 1996 to 2016.
There are 13.2 thousand observations and 14 features. This dataset can be used
to answer questions 4 and 6 above.

2. The data set from
https://www.kaggle.com/sebastianmantey/nba-free-throws/downloads/nba-free-throws.zip/1
was collected by a Kaggle user got the content from ESPN.com. It is a collection
of statistics of NBA free throws between 2006 and 2016 of who and whether they
made it in or not. There are 618 thousand observations and 11 features. This
dataset can be used to answer questions 5, 6, and 7 above.

3. The data set from
https://www.kaggle.com/pschale/mlb-pitch-data-20152018
was collected by using statcast, integrates doppler radar and high definition
video to measure aspects of the game such as pitching, fielding, and base-running.
There are 740,389 observations and 11 features. This answers question 8 above.

4. The data set from
https://www.kaggle.com/jwals96/player-stats-for-every-2018-mlb-game-through-816/downloads/player-stats-for-every-2018-mlb-game-through-816.zip/1
was collected by a Kaggle user who collected dataset from Baseball-reference.com.
This dataset provides both batting and hitting stats for each individual players
for every game in 2018. There are 28,283 observations and 28 features.
Through this, question 9 and 10 can be answered.

5. The data set from
https://www.kaggle.com/ghopkins/nba-injuries-2010-2018/downloads/nba-injuries-2010-2018.zip/1
was scraped from prosportstransaction.com. This dataset provides various types of
injuries that NBA players experience from 2010-2018. There are 9,784 observations,
and 28 features. This dataset is useful to get some answers about question
11, 12, and 13.
