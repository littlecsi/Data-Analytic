# run without --dry-run
system("git clean -xfd -e node_modules -e revdep")
